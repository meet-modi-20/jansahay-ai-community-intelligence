# Firebase integration

The included MVP uses SQLite locally so it can run without cloud credentials.

For a cloud deployment:

1. Create a Firebase project.
2. Enable Authentication.
3. Enable Firestore.
4. Create a Web App.
5. Add the public Firebase Web configuration to the frontend.
6. Keep service-account credentials out of GitHub.
7. Replace the local persistence layer with Firestore transactions/listeners.

Suggested collection: `issues`

Suggested document:

```json
{
  "text": "Garbage has not been collected...",
  "latitude": 30.7333,
  "longitude": 76.7794,
  "category": "Sanitation",
  "severity": "HIGH",
  "impact": 500,
  "recommended_action": "Immediate waste collection",
  "status": "Reported",
  "department": "",
  "created_at": "timestamp"
}
```
