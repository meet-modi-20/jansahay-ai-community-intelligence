-- JANSAHAY BigQuery-ready analytics table.
-- Replace YOUR_PROJECT with your Google Cloud project ID.

CREATE TABLE IF NOT EXISTS `YOUR_PROJECT.jansahay.issues` (
  id INT64,
  text STRING,
  latitude FLOAT64,
  longitude FLOAT64,
  category STRING,
  severity STRING,
  context STRING,
  impact INT64,
  recommended_action STRING,
  status STRING,
  department STRING,
  created_at TIMESTAMP
);

-- Issue volume by category
SELECT category, COUNT(*) AS report_count
FROM `YOUR_PROJECT.jansahay.issues`
GROUP BY category
ORDER BY report_count DESC;

-- Recurring geographic hotspots
SELECT
  ROUND(latitude, 3) AS lat_cluster,
  ROUND(longitude, 3) AS lng_cluster,
  COUNT(*) AS reports
FROM `YOUR_PROJECT.jansahay.issues`
GROUP BY lat_cluster, lng_cluster
HAVING COUNT(*) >= 3
ORDER BY reports DESC;
