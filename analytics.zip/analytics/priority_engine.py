from datetime import datetime, timezone

SEVERITY_POINTS = {
    "CRITICAL": 100,
    "HIGH": 75,
    "MEDIUM": 45,
    "LOW": 20
}


def calculate_priority(issue):
    """
    Transparent MVP scoring model:
    severity 45% + impact 20% + location/context 15%
    + recency 10% + unresolved status 10%.
    """
    severity = SEVERITY_POINTS.get(
        str(issue.get("severity", "")).upper(), 20
    )

    impact = min(float(issue.get("impact") or 0), 1000) / 1000 * 100

    context = str(issue.get("context", "")).lower()
    location_impact = 100 if any(
        word in context
        for word in ["school", "hospital", "residential", "market"]
    ) else 40

    try:
        created = datetime.fromisoformat(
            str(issue.get("created_at", "")).replace("Z", "+00:00")
        )
        age_hours = max(
            0,
            (datetime.now(timezone.utc) - created).total_seconds() / 3600
        )
        recency = max(0, 100 - min(age_hours, 100))
    except Exception:
        recency = 50

    unresolved = 100 if issue.get("status") != "Resolved" else 0

    score = (
        severity * 0.45
        + impact * 0.20
        + location_impact * 0.15
        + recency * 0.10
        + unresolved * 0.10
    )

    return round(score, 2)
