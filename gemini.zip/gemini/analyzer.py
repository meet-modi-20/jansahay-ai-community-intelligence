import base64
import json
import os

try:
    from google import genai
    from google.genai import types
except ImportError:
    genai = None
    types = None


DEMO_ANALYSIS = {
    "category": "Sanitation",
    "severity": "HIGH",
    "context": "Garbage accumulation reported in a residential/community area.",
    "impact": 500,
    "recommended_action": "Immediate waste collection and site inspection."
}


def _clean_json(text):
    text = text.strip()
    if text.startswith("```"):
        text = text.replace("```json", "", 1).replace("```", "").strip()
    return json.loads(text)


def analyze_issue(text, image_base64=None, latitude=None, longitude=None):
    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key or genai is None:
        return DEMO_ANALYSIS.copy()

    client = genai.Client(api_key=api_key)
    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

    prompt = f"""
You are the civic issue intelligence layer for JANSAHAY.

Analyze this citizen report and return ONLY valid JSON with:
category, severity, context, impact, recommended_action

Allowed severity values: LOW, MEDIUM, HIGH, CRITICAL.
impact must be an integer estimate of affected people; if unknown, use 0.
Do not invent exact facts.

Citizen report:
{text}

Location:
latitude={latitude}
longitude={longitude}
"""

    contents = [prompt]

    if image_base64:
        raw = image_base64.split(",", 1)[-1]
        image_bytes = base64.b64decode(raw)
        contents.append(
            types.Part.from_bytes(
                data=image_bytes,
                mime_type="image/jpeg"
            )
        )

    response = client.models.generate_content(
        model=model,
        contents=contents
    )

    try:
        result = _clean_json(response.text)
    except Exception:
        return DEMO_ANALYSIS.copy()

    return {
        "category": str(result.get("category", "Other")),
        "severity": str(result.get("severity", "MEDIUM")).upper(),
        "context": str(result.get("context", "")),
        "impact": int(result.get("impact", 0) or 0),
        "recommended_action": str(
            result.get(
                "recommended_action",
                "Review and assign to the appropriate department."
            )
        )
    }
