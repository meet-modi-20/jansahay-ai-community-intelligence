let map;
let markers = [];

const $ = (id) => document.getElementById(id);

function initMap() {
  const center = { lat: 30.7333, lng: 76.7794 };
  map = new google.maps.Map($("map"), {
    center,
    zoom: 13,
    mapTypeControl: false,
    streetViewControl: false
  });
  loadIssues();
}

window.initMap = initMap;

function severityClass(s) {
  return String(s || "MEDIUM").toUpperCase();
}

async function loadSummary() {
  const data = await fetch("/api/summary").then(r => r.json());
  $("stats").innerHTML = `
    <div class="stat"><b>${data.total}</b><span>Total reports</span></div>
    <div class="stat"><b>${data.high_priority}</b><span>High/Critical issues</span></div>
    <div class="stat"><b>${data.resolved}</b><span>Resolved</span></div>
    <div class="stat"><b>${Object.keys(data.categories).length}</b><span>Issue categories</span></div>
  `;
}

function renderIssues(items) {
  $("issues").innerHTML = items.map((x, i) => `
    <div class="issue">
      <div class="issue-head">
        <strong>#${i + 1} ${escapeHtml(x.category)} · ${escapeHtml(x.department || "Unassigned")}</strong>
        <span class="severity ${severityClass(x.severity)}">${escapeHtml(x.severity)}</span>
      </div>
      <div>${escapeHtml(x.text)}</div>
      <div class="meta">Priority score: ${x.priority_score} · Status: ${escapeHtml(x.status)} · Impact: ~${x.impact || 0}</div>
      <div class="meta">Recommended: ${escapeHtml(x.recommended_action || "")}</div>
      <div class="actions">
        <button onclick="updateIssue(${x.id}, 'Assigned', 'SANITATION')">Assign</button>
        <button onclick="updateIssue(${x.id}, 'In Progress', 'ENGINEERING')">In Progress</button>
        <button onclick="updateIssue(${x.id}, 'Resolved', x.department || '')">Resolve</button>
      </div>
    </div>
  `).join("");

  if (map) {
    markers.forEach(m => m.setMap(null));
    markers = [];
    items.forEach(x => {
      if (x.latitude == null || x.longitude == null) return;
      const marker = new google.maps.Marker({
        map,
        position: {lat: Number(x.latitude), lng: Number(x.longitude)},
        title: `${x.category} — ${x.severity}`
      });
      markers.push(marker);
    });
  }
}

async function loadIssues() {
  const items = await fetch("/api/issues").then(r => r.json());
  renderIssues(items);
  loadSummary();
}

async function updateIssue(id, status, department) {
  await fetch(`/api/issues/${id}`, {
    method: "PATCH",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({status, department})
  });
  loadIssues();
}

$("issueForm").addEventListener("submit", async (event) => {
  event.preventDefault();

  const file = $("image").files[0];
  let image_base64 = null;

  if (file) image_base64 = await fileToBase64(file);

  const response = await fetch("/api/issues", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({
      text: $("issueText").value,
      latitude: $("lat").value || null,
      longitude: $("lng").value || null,
      image_base64
    })
  });

  const data = await response.json();

  if (!response.ok) {
    alert(data.error || "Unable to submit.");
    return;
  }

  $("result").classList.remove("hidden");
  $("result").innerHTML = `
    <strong>AI analysis complete</strong><br>
    Category: ${escapeHtml(data.analysis.category)}<br>
    Severity: ${escapeHtml(data.analysis.severity)}<br>
    Impact: ~${data.analysis.impact}<br>
    Action: ${escapeHtml(data.analysis.recommended_action)}
    ${data.demo_mode ? "<br><small>Demo mode: configure GEMINI_API_KEY for live Gemini analysis.</small>" : ""}
  `;

  $("issueForm").reset();
  loadIssues();
});

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

loadSummary();
loadIssues();
