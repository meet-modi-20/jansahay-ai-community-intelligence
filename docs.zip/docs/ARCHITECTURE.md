# JANSAHAY architecture

```text
Citizen
  |
  | photo + voice + text + location
  v
JANSAHAY API
  |
  v
Gemini multimodal analysis
  |
  +--> category / severity / context / impact / action
  |
  v
Issue storage
  |
  +--> Firebase (cloud path)
  +--> SQLite (local MVP fallback)
  |
  +--> Google Maps Platform
  |       +--> markers
  |       +--> hotspots
  |
  +--> BigQuery
          +--> trends
          +--> recurring hotspots
          +--> historical analytics
  |
  v
Authority dashboard
  +--> prioritize
  +--> assign
  +--> track
  +--> resolve
```

## Design principle

**AI recommends. Humans decide. Departments act.**

The MVP priority score is transparent and explainable; it is not intended to replace public-authority judgment.
